<footer class="main-footer clearfix">
	<div class="pull-left hidden-xs">
	<b><?php  echo $this->config->item("product_short_name");?></b>
	<?php echo $this->config->item("product_version");?> - 
	<?php echo '<a target="_BLANK" href="'.site_url().'"><b>'.$this->config->item("institute_address1").'</b></a>'; ?>

	</div>
</footer>