<?php

$lang = array (
  'how to get recaptcha site key and secret key' => 'recaptcha sitesi anahtarı ve gizli anahtarı almak için nasıl',
  'recaptcha secret key' => 'Güvenlik Sorgulama gizli anahtar',
  'recaptcha site key' => 'Güvenlik Sorgulama site anahtar',
  'you have not enter captcha' => 'Sen güvenlik kodunu girin değil',
);