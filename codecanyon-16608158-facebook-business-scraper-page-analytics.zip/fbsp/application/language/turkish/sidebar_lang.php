<?php 

$lang = 


array (
  'administration' => 'yönetim',
  'user management' => 'Kullanıcı yönetimi',
  'send notification' => 'bildirim göndermek',
  'settings' => 'ayarlar',
  'general settings' => 'Genel Ayarlar',
  'email settings' => 'e-posta ayarları',
  'payment' => 'ödeme',
  'dashboard' => 'gösterge paneli',
  'payment settings' => 'ödeme ayarları',
  'payment history' => 'ödeme geçmişi',
  'facebook settings' => 'facebook ayarları',
  'lead settings' => 'kurşun ayarları',
  'proxy settings' => 'vekil sunucu Ayarları',
  'delete junk files/data' => 'gereksiz dosyaları silme / veri',
  'read documentation' => 'belgeleri okuyun',
  'event search' => 'olay arama',
  'group search' => 'grup arama',
  'page search by location' => 'Konuma göre sayfa arama',
  'page search' => 'sayfa arama',
  'user search' => 'kullanıcı arama',
  'lead list' => 'kurşun liste',
  'native API' => 'yerel API'
)

;

