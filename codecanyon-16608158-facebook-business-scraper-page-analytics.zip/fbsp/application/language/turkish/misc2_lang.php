<?php

$lang = array (
  'advertisement settings' => 'Reklam ayarları',
  'i want to advertise' => 'Ben reklamını yapmak istiyorum',
  'i do not want advertise' => 'Ben reklam istemediğiniz',
  'google API settings' => 'google API ayarları',
  'google API key' => 'google API anahtarı',
  'please enter google API key and make sure Google Map JavaScript API is enabled.' => 'google API anahtarı girin ve emin Google Map JavaScript API etkin olduğundan emin olun.',
  'how to get google API key?' => 'Nasıl google API anahtarı almak için?',
  'how to create mailchimp account?' => 'Nasıl MailChimp hesap oluşturmak için?',
  'how to create facebook app and get app id & app secret?' => 'Nasıl facebook uygulaması oluşturmak ve uygulama kimliği ve uygulama sırrı olsun?',
  'cron job' => 'cron işi',
);