<?php
$lang = 
array (
  'Total Search Vs Result Found (Today\'s Report)' => 'Bulunan Sonuç Vs Toplam Arama (Bugünün Raporu)',
  'Total Collected Emails (Today\'s Report)' => 'Toplam Toplanan e-postalar (Bugünün Raporu)',
  'widget' => 'Widget',
  'domain name' => 'alan adı',
  'frame border' => 'çerçeve sınır',
  'frame width' => 'çerçeve genişliği',
  'frame height' => 'çerçeve yüksekliği',
  'frame background HEX' => 'Çerçeve arka plan HEX',
  'text color HEX' => 'metin rengi HEX',
  'input border color HEX' => 'giriş kenarlık rengi HEX',
  'icon color HEX' => 'simge rengi HEX',
  'button style' => 'düğme stili',
  'get widget embed code' => 'Widget embed kodunu almak',
  'click to copy' => 'kopyalamak için tıklayın',
  'widget preview' => 'Widget önizleme',
  'how the widget will look in to your website?' => 'nasıl Widget web sitenize bakacağız?',
  'have a look' => 'bir göz',
   "copy the html code, put it in the websites's html and let website users to use awesome facebook page search" =>", Html kodu kopyalayın web sitelerinin en html koymak ve web sitesi kullanıcıları müthiş facebook sayfası arama kullanmak için izin",
  "emails from page search"=>"Sayfa arama e-postaları - arka uç",
  "emails from guest search"=>"Sayfa arama e-postaları - önuç",
  "emails from guest user"=>"Misafir kullanıcı e-postaları",
  "page list searched by guests"=>"Konuklar tarafından arandı sayfa listesi",
  "total search" => "toplam arama",
  "total result found" => "Toplam sonuç bulundu"
);