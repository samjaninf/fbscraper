<?php

$lang = 
array (
  'administration' => 'Verwaltung',
  'user management' => 'Benutzerverwaltung',
  'send notification' => 'senden Benachrichtigung',
  'settings' => 'Einstellungen',
  'general settings' => 'Allgemeine Einstellungen',
  'email settings' => 'Email Einstellungen',
  'payment' => 'Zahlung',
  'dashboard' => 'Instrumententafel',
  'payment settings' => 'Zahlungseinstellungen',
  'payment history' => 'Zahlungshistorie',
  'facebook settings' => 'Facebook -Einstellungen',
  'lead settings' => 'Blei-Einstellungen',
  'proxy settings' => 'Proxy-Einstellungen',
  'delete junk files/data' => 'löschen Junk-Dateien / Daten',
  'read documentation' => 'lesen Dokumentation',
  'event search' => 'Ereignissuche',
  'group search' => 'Gruppensuche',
  'page search by location' => 'Seite Suche nach Standort',
  'page search' => 'Seite suchen',
  'user search' => 'Benutzersuche',
  'lead list' => 'Lead-Liste',
  'native API' => 'Einheimische API'
);