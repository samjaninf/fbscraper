<?php

$lang = array (
  'advertisement settings' => 'Werbung Einstellungen',
  'i want to advertise' => 'Ich mÃ¶chte werben',
  'i do not want advertise' => 'Ich will nicht werben',
  'google API settings' => 'Google-API-Einstellungen',
  'google API key' => 'Google-API-SchlÃ¼ssel',
  'please enter google API key and make sure Google Map JavaScript API is enabled.' => 'Bitte geben Sie Google-API-SchlÃ¼ssel und stellen Sie sicher, dass Google Map JavaScript-API aktiviert ist.',
  'how to get google API key?' => 'Wie Google-API-SchlÃ¼ssel zu bekommen?',
  'how to create mailchimp account?' => 'Wie MailChimp Konto zu erstellen?',
  'how to create facebook app and get app id & app secret?' => 'Wie Facebook -App zu erstellen und App-ID & app Geheimnis bekommen?',
  'cron job' => 'Cron-Job',
);