<?php

$lang = array (
  'how to get recaptcha site key and secret key' => 'Wie man recaptcha Site-Schlüssel und geheimen Schlüssel erhalten',
  'recaptcha secret key' => 'Recaptcha geheimen Schlüssel',
  'recaptcha site key' => 'Recaptcha Site-Schlüssel',
  'you have not enter captcha' => 'Sie haben eingeben nicht Captcha',
);

