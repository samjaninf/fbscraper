<?php 
$lang = 

array (
  'Total Search Vs Result Found (Today\'s Report)' => 'Insgesamt Suche Vs Ergebnis gefunden (heutiger Bericht)',
  'Total Collected Emails (Today\'s Report)' => 'Insgesamt Gesammelte E-Mails (heutiger Bericht)',
  'widget' => 'Widget',
  'domain name' => 'Domain-Namen',
  'frame border' => 'Bilderrandbereich',
  'frame width' => 'Rahmenbreite',
  'frame height' => 'Rahmenhöhe ',
  'frame background HEX' => 'Frame-Hintergrund HEX',
  'text color HEX' => 'Textfarbe HEX',
  'input border color HEX' => 'Eingangsrahmenfarbe HEX',
  'icon color HEX' => 'Symbolfarbe HEX',
  'button style' => 'Button-Stil',
  'get widget embed code' => 'Get Widget Code einbetten',
  'click to copy' => 'Klicken kopieren',
  'widget preview' => 'Widget Vorschau',
  'how the widget will look in to your website?' => 'wie das Widget auf Ihre Website aussehen in werden?',
  'have a look' => 'Guck mal',
  "copy the html code, put it in the websites's html and let website users to use awesome facebook page search" =>"Kopieren Sie den HTML-Code, steckte es in den HTML-Websites und lassen Website-Nutzer ehrfürchtige Facebook -Seite Suche verwenden",
  "emails from page search"=>"Seite Suche von E-Mails - Backend",
  "emails from guest search"=>"Seite Suche von E-Mails - Frontend",
  "emails from guest user"=>"Gastbenutzer E-Mails",
  "page list searched by guests"=>"Seite Liste von Gästen gesucht",
  "total search" => "Gesamtsuche",
  "total result found" => "Gesamtergebnis gefunden"
  );