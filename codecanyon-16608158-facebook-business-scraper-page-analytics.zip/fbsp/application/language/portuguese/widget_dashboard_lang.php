<?php

$lang = 
array (
  'Total Search Vs Result Found (Today\'s Report)' => 'Total de Pesquisa Vs resultado encontrado (Relatório de hoje)',
  'Total Collected Emails (Today\'s Report)' => 'Total de e-mails coletados (relatório de hoje)',
  'widget' => 'ferramenta',
  'domain name' => 'nome de domínio',
  'frame border' => 'moldura',
  'frame width' => 'largura da moldura',
  'frame height' => 'altura do quadro',
  'frame background HEX' => 'Frame do fundo do HEX',
  'text color HEX' => 'HEX cor do texto',
  'input border color HEX' => 'input HEX cor da borda',
  'icon color HEX' => 'HEX cor do ícone',
  'button style' => 'estilo de botão',
  'get widget embed code' => 'Obter o código embutido Widget',
  'click to copy' => 'clique para copiar',
  'widget preview' => 'visualização do widget',
  'how the widget will look in to your website?' => 'como o widget vai olhar para o seu site?',
  'have a look' => 'dar uma olhada',
   "copy the html code, put it in the websites's html and let website users to use awesome facebook page search" =>"copiar o código html, colocá-lo em HTML do Web site e permitir que os usuários do site para usar pesquisa impressionante página de facebook",
  "emails from page search"=>"e-mails pesquisa Página - back-end",
  "emails from guest search"=>"e-mails pesquisa Página - Interface",
  "emails from guest user"=>"Os usuários convidados e-mails",
  "page list searched by guests"=>"lista de páginas procurou pelos hóspedes",
  "total search" => "total de busca",
  "total result found" => "resultado total encontrado"
)
;