<?php


$lang = array (
  'how to get recaptcha site key and secret key' => 'Como obter a chave local recaptcha e chave secreta',
  'recaptcha secret key' => 'Recaptcha chave secreta',
  'recaptcha site key' => 'chave local Recaptcha',
  'you have not enter captcha' => 'Você não entrar captcha',
);