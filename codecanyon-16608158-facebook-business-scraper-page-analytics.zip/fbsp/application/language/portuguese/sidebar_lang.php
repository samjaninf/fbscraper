<?php 

$lang = 

array (
  'administration' => 'administração',
  'user management' => 'gerenciamento de usuários',
  'send notification' => 'enviar uma notificação',
  'settings' => 'configurações',
  'general settings' => 'Configurações Gerais',
  'email settings' => 'configurações de e-mail',
  'payment' => 'pagamento',
  'dashboard' => 'painel de instrumentos',
  'payment settings' => 'configurações de pagamento',
  'payment history' => 'Histórico de pagamento',
  'facebook settings' => 'configurações do Facebook',
  'lead settings' => 'configurações de chumbo',
  'proxy settings' => 'configurações de proxy',
  'delete junk files/data' => 'apagar arquivos de lixo / data',
  'read documentation' => 'ler a documentação',
  'event search' => 'pesquisa de eventos',
  'group search' => 'pesquisa do grupo',
  'page search by location' => 'página de pesquisa por localização',
  'page search' => 'página de pesquisa',
  'user search' => 'pesquisa do usuário',
  'lead list' => 'lista de chumbo',
  'native API' => 'API nativa'
)


;