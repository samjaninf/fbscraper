<?php

$lang = array (
  'advertisement settings' => 'configurações Publicidade',
  'i want to advertise' => 'Quero anunciar',
  'i do not want advertise' => 'Eu não quero fazer propaganda',
  'google API settings' => 'configurações API do Google',
  'google API key' => 'chave de API do Google',
  'please enter google API key and make sure Google Map JavaScript API is enabled.' => 'Por favor insira a chave de API do Google e certifique-se API Google Map JavaScript está habilitado.',
  'how to get google API key?' => 'Como obter chave de API do Google?',
  'how to create mailchimp account?' => 'Como criar uma conta MailChimp?',
  'how to create facebook app and get app id & app secret?' => 'Como criar facebook app e obter app ID & segredo app?',
  'cron job' => 'cron',
);