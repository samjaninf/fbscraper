<?php

$lang = array (
  'how to get recaptcha site key and secret key' => 'How to get recaptcha site key and secret key',
  'recaptcha secret key' => 'Recaptcha secret key',
  'recaptcha site key' => 'Recaptcha site key',
  'you have not enter captcha' => 'You have not enter captcha',
);