<?php 

$lang = array (
  'administration' => 'Administration',
  'user management' => 'User Management',
  'send notification' => 'Send Notification',
  'settings' => 'Settings',
  'general settings' => 'General Settings',
  'email settings' => 'Email Settings',
  'payment' => 'Payment Management',
  'dashboard' => 'Dashboard',
  'payment settings' => 'Payment Settings',
  'payment history' => 'Payment History',
  'facebook settings' => 'Facebook Settings',
  'lead settings' => 'Lead Settings',
  'proxy settings' => 'Proxy Settings',
  'delete junk files/data' => 'Delete Junk Files/data',
  'read documentation' => 'Read Documentation',
  'event search' => 'Event Search',
  'group search' => 'Group Search',
  'page search by location' => 'Page Search By Location',
  'page search' => 'Page Search',
  'user search' => 'User Search',
  'lead list' => 'Lead List',
  'native API' => 'Native API'
);