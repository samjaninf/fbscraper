<?php

$lang = array (
  'advertisement settings' => 'Advertisement Settings',
  'i want to advertise' => 'I want to advertise',
  'i do not want advertise' => 'I do not want advertise',
  'google API settings' => 'Google API Settings',
  'google API key' => 'Google API key',
  'please enter google API key and make sure Google Map JavaScript API is enabled.' => 'Please enter google API key and make sure Google Map JavaScript API is enabled.',
  'how to get google API key?' => 'How to get google API key?',
  'how to create mailchimp account?' => 'How to create mailchimp account?',
  'how to create facebook app and get app id & app secret?' => 'How to create facebook app and get app id & app secret?',
  'cron job' => 'Cron Job',
);