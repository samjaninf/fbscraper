<?php
$lang = 
array (
  'Total Search Vs Result Found (Today\'s Report)' => 'Total Search Vs Result Found (Today\'s Report)',
  'Total Collected Emails (Today\'s Report)' => 'Total Collected Emails (Today\'s Report)',
  'widget' => 'Widget',
  'domain name' => 'Domain Name',
  'frame border' => 'Frame Border',
  'frame width' => 'Frame Width',
  'frame height' => 'Frame Height',
  'frame background HEX' => 'Frame background HEX',
  'text color HEX' => 'Text color HEX',
  'input border color HEX' => 'Input border color HEX',
  'icon color HEX' => 'Icon color HEX',
  'button style' => 'Button style',
  'get widget embed code' => 'Get widget embed code',
  'click to copy' => 'Click to copy',
  'widget preview' => 'Widget preview',
  'how the widget will look in to your website? ' => 'How the widget will look in to your website? ',
  'have a look' => 'Have a look',
  "copy the html code, put it in the websites's html and let website users to use awesome facebook page search" =>"Copy the html code, put it in the websites's html and let website users to use awesome facebook page search",
  "emails from page search"=>"Page search emails - backend",
  "emails from guest search"=>"Page search emails - frontend",
  "emails from guest user"=>"Guest users emails",
  "page list searched by guests"=>"Page List Searched by Guests",
  "total search" => "Total Search",
  "total result found" => "Total Result Found"
);