<?php

$lang = array (
  'advertisement settings' => 'Διαφήμιση ρυθμίσεις',
  'i want to advertise' => 'Θέλω να διαφημίσει',
  'i do not want advertise' => 'Δεν θέλετε να διαφημίσετε',
  'google API settings' => 'Ρυθμίσεις API Google',
  'google API key' => 'κλειδί API Google',
  'please enter google API key and make sure Google Map JavaScript API is enabled.' => 'Παρακαλούμε, εισάγετε κλειδί API Google και βεβαιωθείτε API Google Map την Javascript είναι ενεργοποιημένη.',
  'how to get google API key?' => 'Πώς να πάρετε το κλειδί API Google;',
  'how to create mailchimp account?' => 'Πώς να δημιουργήσετε MailChimp λογαριασμό;',
  'how to create facebook app and get app id & app secret?' => 'Πώς να δημιουργήσετε facebook app και να πάρει app id & app μυστικό;',
  'cron job' => 'cron δουλειά',
);