<?php
$lang = 
array (
  'Total Search Vs Result Found (Today\'s Report)' => 'Σύνολο αναζήτησης Vs αποτελεσμάτων Βρέθηκαν (σημερινή έκθεση)',
  'Total Collected Emails (Today\'s Report)' => 'Σύνολο Συλλέγονται Emails (σημερινή έκθεση)',
  'widget' => 'widget',
  'domain name' => 'όνομα τομέα',
  'frame border' => 'περίγραμμα πλαισίου',
  'frame width' => 'το πλάτος του πλαισίου',
  'frame height' => 'ύψος πλαισίου',
  'frame background HEX' => 'πλαίσιο HEX φόντο',
  'text color HEX' => 'κείμενο χρώμα HEX',
  'input border color HEX' => 'εισόδου στα σύνορα χρώμα HEX',
  'icon color HEX' => 'εικονίδιο χρώματος HEX',
  'button style' => 'στυλ κουμπί',
  'get widget embed code' => 'πάρετε widget κώδικα ενσωμάτωσης',
  'click to copy' => 'κάντε κλικ για να αντιγράψετε',
  'widget preview' => 'widget προεπισκόπηση',
  'how the widget will look in to your website?' => 'πώς το widget θα δούμε στην στην ιστοσελίδα σας;',
  'have a look' => 'κοίτα',
   "copy the html code, put it in the websites's html and let website users to use awesome facebook page search" =>"αντιγράψτε τον κώδικα html, το βάζουμε σε html τις ιστοσελίδες και επιτρέπει στους χρήστες την ιστοσελίδα για να χρησιμοποιήσετε το φοβερό αναζήτησης σελίδα στο facebook",
  "emails from page search"=>"emails σελίδα αναζήτησης - backend",
  "emails from guest search"=>"emails σελίδα αναζήτησης - frontend",
  "emails from guest user"=>"emails Σχόλια χρηστών",
  "page list searched by guests"=>"Λίστα σελίδα αναζήτηση από τους επισκέπτες",
  "total search" => "συνολικής αναζήτηση",
  "total result found" => "συνολικό αποτέλεσμα βρέθηκε"
)

;