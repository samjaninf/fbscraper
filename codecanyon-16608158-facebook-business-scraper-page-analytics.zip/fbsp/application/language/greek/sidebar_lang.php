<?php
$lang = 
array (
  'administration' => 'διαχείριση',
  'user management' => 'διαχείρισης χρηστών',
  'send notification' => 'αποστέλλει ειδοποίηση',
  'settings' => 'Ρυθμίσεις',
  'general settings' => 'Γενικές Ρυθμίσεις',
  'email settings' => 'ρυθμίσεις email',
  'payment' => 'πληρωμή',
  'dashboard' => 'ταμπλό',
  'payment settings' => 'ρυθμίσεις πληρωμής',
  'payment history' => 'το ιστορικό πληρωμών',
  'facebook settings' => 'ρυθμίσεις facebook',
  'lead settings' => 'ρυθμίσεις μολύβδου',
  'proxy settings' => 'ρυθμίσεων του διακομιστή μεσολάβησης',
  'delete junk files/data' => 'διαγράψετε τα άχρηστα αρχεία / δεδομένα',
  'read documentation' => 'διαβάστε την τεκμηρίωση',
  'event search' => 'αναζήτηση εκδήλωση',
  'group search' => 'αναζήτηση ομάδας',
  'page search by location' => 'Σελίδα αναζήτησης ανά περιοχή',
  'page search' => 'αναζήτηση σελίδα',
  'user search' => 'αναζήτησης των χρηστών',
  'lead list' => 'Λίστα μόλυβδος',
  'native API' => 'ντόπιος API'
);