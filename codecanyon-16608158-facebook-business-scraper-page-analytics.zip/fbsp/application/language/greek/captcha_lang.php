<?php

$lang = array (
  'how to get recaptcha site key and secret key' => 'Πώς να πάρετε το κλειδί ιστοσελίδα recaptcha και το μυστικό κλειδί',
  'recaptcha secret key' => 'Recaptcha μυστικό κλειδί',
  'recaptcha site key' => 'κλειδί ιστοσελίδα recaptcha',
  'you have not enter captcha' => 'Δεν έχετε εισέλθει captcha',
);