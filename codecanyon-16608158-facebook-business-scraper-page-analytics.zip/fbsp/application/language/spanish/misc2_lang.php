<?php

$lang = array (
  'advertisement settings' => 'ajustes Publicidad',
  'i want to advertise' => 'Quiero hacer publicidad',
  'i do not want advertise' => 'No quiero que Anuncia',
  'google API settings' => 'configuración de la API de Google',
  'google API key' => 'clave de API de Google',
  'please enter google API key and make sure Google Map JavaScript API is enabled.' => 'Por favor, introduzca la clave de API de Google y asegúrese de que la API de Google Maps JavaScript está habilitado.',
  'how to get google API key?' => 'Cómo obtener la clave de API de Google?',
  'how to create mailchimp account?' => 'Cómo crear una cuenta de MailChimp?',
  'how to create facebook app and get app id & app secret?' => 'Cómo crear aplicación de Facebook y obtener ID de aplicación y aplicación secreto?',
  'cron job' => 'trabajo cron',
);