<?php


$lang = array (
  'how to get recaptcha site key and secret key' => 'Cómo obtener la clave sitio Reconocer texto y clave secreta',
  'recaptcha secret key' => 'Reconocer texto clave secreta',
  'recaptcha site key' => 'Reconocer texto del sitio clave',
  'you have not enter captcha' => 'No ha introducir código de imagen',
);