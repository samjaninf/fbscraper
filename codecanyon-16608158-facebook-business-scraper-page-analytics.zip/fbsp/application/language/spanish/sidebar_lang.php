<?php
$lang =


array (
  'administration' => 'administración',
  'user management' => 'Gestión de usuarios',
  'send notification' => 'Enviar notificación',
  'settings' => 'ajustes',
  'general settings' => 'Configuración general',
  'email settings' => 'Ajustes del correo electrónico',
  'payment' => 'pago',
  'dashboard' => 'tablero',
  'payment settings' => 'la configuración de pagos',
  'payment history' => 'historial de pagos',
  'facebook settings' => 'la configuración de Facebook',
  'lead settings' => 'configuración de la trayectoria',
  'proxy settings' => 'configuración de proxy',
  'delete junk files/data' => 'eliminar archivos basura / datos',
  'read documentation' => 'leer la documentación',
  'event search' => 'búsqueda de eventos',
  'group search' => 'de búsqueda de grupos',
  'page search by location' => 'La página de búsqueda por ubicación',
  'page search' => 'búsqueda de la página',
  'user search' => 'búsqueda de los usuarios',
  'lead list' => 'lista de plomo',
  'native API' => 'API nativa'
)
;