<?php
$lang = 
array (
  'Total Search Vs Result Found (Today\'s Report)' => 'Buscar Vs total de los resultados encontrados (Informe de hoy)',
  'Total Collected Emails (Today\'s Report)' => 'Los correos electrónicos recogidos totales (El informe de hoy)',
  'widget' => 'Reproductor',
  'domain name' => 'nombre de dominio',
  'frame border' => 'Frontera del marco',
  'frame width' => 'ancho del marco',
  'frame height' => 'altura del marco',
  'frame background HEX' => 'Marco del fondo de HEX',
  'text color HEX' => 'texto en color HEX',
  'input border color HEX' => 'HEX color del borde de entrada',
  'icon color HEX' => 'icono de color HEX',
  'button style' => 'estilo de botón',
  'get widget embed code' => 'Obtener código Reproductor',
  'click to copy' => 'clic para copiar',
  'widget preview' => 'widget de vista previa',
  'how the widget will look in to your website?' => 'cómo el widget buscará en su sitio web?',
  'have a look' => 'echar un vistazo',
   "copy the html code, put it in the websites's html and let website users to use awesome facebook page search" =>"copiar el código html, lo puso en el código HTML de las páginas web y permiten a los usuarios del sitio web para uso impresionante de búsqueda página de facebook",
  "emails from page search"=>"mensajes de correo electrónico de búsqueda - página back-end",
  "emails from guest search"=>"mensajes de correo electrónico de búsqueda - página frontend",
  "emails from guest user"=>"Los usuarios invitados correos electrónicos",
  "page list searched by guests"=>"lista de páginas buscado por los clientes",
  "total search" => "total de la búsqueda",
  "total result found" => "resultado total encontrada"
);