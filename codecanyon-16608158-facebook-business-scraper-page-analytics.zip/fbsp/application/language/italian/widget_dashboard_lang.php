<?php
$lang = 
array (
  'Total Search Vs Result Found (Today\'s Report)' => 'Cerca Totale Vs risultato trovato (la relazione di oggi)',
  'Total Collected Emails (Today\'s Report)' => 'Messaggi di posta elettronica raccolti totali (la relazione di oggi)',
  'widget' => 'widget di',
  'domain name' => 'nome di dominio',
  'frame border' => 'confine cornice',
  'frame width' => 'larghezza del telaio',
  'frame height' => 'altezza del telaio',
  'frame background HEX' => 'cornice di sfondo HEX',
  'text color HEX' => 'testo di colore HEX',
  'input border color HEX' => 'Ingresso colore del bordo HEX',
  'icon color HEX' => 'icona di colore HEX',
  'button style' => 'stile del tasto',
  'get widget embed code' => 'ottenere il codice embed widget di',
  'click to copy' => 'Clicca per copiare',
  'widget preview' => 'widget di anteprima',
  'how the widget will look in to your website?' => 'come il widget sarà al tuo sito web?',
  'have a look' => 'dare un\'occhiata',
   "copy the html code, put it in the websites's html and let website users to use awesome facebook page search" =>"copiare il codice html, metterlo in HTML del sito e consentire agli utenti di siti web di utilizzare impressionante di ricerca pagina facebook",
  "emails from page search"=>"messaggi di posta elettronica Pagina di ricerca - backend",
  "emails from guest search"=>"messaggi di posta elettronica Pagina di ricerca - frontend",
  "emails from guest user"=>"messaggi di posta elettronica ad utenti ospiti",
  "page list searched by guests"=>"Lista pagina cercata dagli ospiti",
  "total search" => "Ricerca totale",
  "total result found" => "risultato complessivo trovato"
)




;