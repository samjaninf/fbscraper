<?php

$lang = array (
  'advertisement settings' => 'impostazioni Pubblicità',
  'i want to advertise' => 'Voglio pubblicizzare',
  'i do not want advertise' => 'Io non voglio pubblicizzare',
  'google API settings' => 'impostazioni API di Google',
  'google API key' => 'chiave API di Google',
  'please enter google API key and make sure Google Map JavaScript API is enabled.' => 'Si prega di inserire chiave API di Google e assicurarsi API di Google Map Javascript sia abilitato.',
  'how to get google API key?' => 'Come ottenere la chiave API di Google?',
  'how to create mailchimp account?' => 'Come creare un account MailChimp?',
  'how to create facebook app and get app id & app secret?' => 'Come creare facebook app e ottenere App ID & app segreto?',
  'cron job' => 'cron',
);