<?php


$lang = array (
  'how to get recaptcha site key and secret key' => 'Come ottenere la chiave sito recaptcha e chiave segreta',
  'recaptcha secret key' => 'chiave segreta Recaptcha',
  'recaptcha site key' => 'chiave del sito Recaptcha',
  'you have not enter captcha' => 'Non hai inserire captcha',
);