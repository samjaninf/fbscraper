<?php 


$lang = 

array (
  'administration' => 'amministrazione',
  'user management' => 'Gestione utenti',
  'send notification' => 'inviare una notifica',
  'settings' => 'impostazioni',
  'general settings' => 'impostazioni generali',
  'email settings' => 'impostazioni e-mail',
  'payment' => 'Pagamento',
  'dashboard' => 'scrivania',
  'payment settings' => 'impostazioni di pagamento',
  'payment history' => 'Storico dei pagamenti',
  'facebook settings' => 'impostazioni facebook',
  'lead settings' => 'impostazioni di piombo',
  'proxy settings' => 'Impostazioni Proxy',
  'delete junk files/data' => 'eliminare i file spazzatura / dati',
  'read documentation' => 'leggere la documentazione',
  'event search' => 'ricerca evento',
  'group search' => 'Ricerca gruppo',
  'page search by location' => 'Ricerca pagina posizione',
  'page search' => 'pagina',
  'user search' => 'Ricerca utente',
  'lead list' => 'lista di piombo',
  'native API' => 'API native'
)

;