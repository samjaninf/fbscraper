<?php

$lang = array (
  'advertisement settings' => 'Реклама настройки',
  'i want to advertise' => 'Я хочу, чтобы рекламировать',
  'i do not want advertise' => 'Я не хочу рекламировать',
  'google API settings' => 'Настройки API Google',
  'google API key' => 'ключ API Google',
  'please enter google API key and make sure Google Map JavaScript API is enabled.' => 'Пожалуйста, введите ключ API Google и убедитесь, что Google Map JavaScript API включен.',
  'how to get google API key?' => 'Как получить ключ API Google?',
  'how to create mailchimp account?' => 'Как создать учетную запись MailChimp?',
  'how to create facebook app and get app id & app secret?' => 'Как создать facebook приложение и получить идентификатор приложения & приложение секрет?',
  'cron job' => 'хрон',
);