<?php


$lang = array (
  'how to get recaptcha site key and secret key' => 'Как получить ключ Recaptcha сайта и секретный ключ',
  'recaptcha secret key' => 'Recaptcha секретный ключ',
  'recaptcha site key' => 'Ключевой сайт Recaptcha',
  'you have not enter captcha' => 'Вы не вводите капчу',
);