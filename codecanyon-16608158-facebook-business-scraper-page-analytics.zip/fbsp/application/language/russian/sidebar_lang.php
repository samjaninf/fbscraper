<?php

$lang = 

array (
  'administration' => 'администрация',
  'user management' => 'Управление пользователями',
  'send notification' => 'отправить уведомление',
  'settings' => 'настройки',
  'general settings' => 'общие настройки',
  'email settings' => 'настройки электронной почты',
  'payment' => 'оплата',
  'dashboard' => 'панель приборов',
  'payment settings' => 'настройки оплаты',
  'payment history' => 'История платежей',
  'facebook settings' => 'настройки Facebook',
  'lead settings' => 'свинцовые настройки',
  'proxy settings' => 'настройки прокси',
  'delete junk files/data' => 'удалить мусорные файлы / данные',
  'read documentation' => 'прочитайте документацию',
  'event search' => 'поиск событий',
  'group search' => 'поисковая группа',
  'page search by location' => 'страница поиска по местоположению',
  'page search' => 'страница поиска',
  'user search' => 'поиск пользователей',
  'lead list' => 'свинец список',
  'native API' => 'родной API'
)

;