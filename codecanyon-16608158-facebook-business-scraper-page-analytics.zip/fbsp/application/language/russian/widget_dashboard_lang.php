<?php
$lang = 
array (
  'Total Search Vs Result Found (Today\'s Report)' => 'Общий поиск Vs Результат Найдено (сегодня отчет)',
  'Total Collected Emails (Today\'s Report)' => 'Всего сообщений электронной почты (Накопленные Сегодняшний отчет)',
  'widget' => 'виджет',
  'domain name' => 'доменное имя',
  'frame border' => 'рамка',
  'frame width' => 'ширина рамы',
  'frame height' => 'высота рамы',
  'frame background HEX' => 'кадр фона HEX',
  'text color HEX' => 'цвет текста HEX',
  'input border color HEX' => 'входной цвет границы HEX',
  'icon color HEX' => 'цвет значка HEX',
  'button style' => 'стиль кнопки',
  'get widget embed code' => 'Получить виджет код',
  'click to copy' => 'нажмите, чтобы скопировать',
  'widget preview' => 'виджет предварительного просмотра',
  'how the widget will look in to your website?' => 'как виджет будет выглядеть в свой веб-сайт?',
  'have a look' => 'Взгляни',
   "copy the html code, put it in the websites's html and let website users to use awesome facebook page search" =>"скопировать HTML-код, поместите его в веб-сайтах HTML-и позволить пользователям сайта использовать удивительный поиск facebook страницы",
  "emails from page search"=>"Страница поиска сообщений электронной почты - Серверные",
  "emails from guest search"=>"Страница поиска сообщений электронной почты - во внешнем интерфейсе",
  "emails from guest user"=>"Гость пользователей электронной почты",
  "page list searched by guests"=>"Список страниц разыскивает гостей",
  "total search" => "Общий поиск",
  "total result found" => "общий результат найдено"
)

;