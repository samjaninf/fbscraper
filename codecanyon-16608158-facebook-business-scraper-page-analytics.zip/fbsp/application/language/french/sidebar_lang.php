<?php 
$lang =
array (
  'administration' => 'administration',
  'user management' => 'Gestion des utilisateurs',
  'send notification' => 'envoyer une notification',
  'settings' => 'paramètres',
  'general settings' => 'réglages généraux',
  'email settings' => 'Paramètres de messagerie',
  'payment' => 'Paiement',
  'dashboard' => 'tableau de bord',
  'payment settings' => 'paramètres de paiement',
  'payment history' => 'historique de paiement',
  'facebook settings' => 'paramètres facebook',
  'lead settings' => 'paramètres de plomb',
  'proxy settings' => 'paramètres du proxy',
  'delete junk files/data' => 'supprimer les fichiers inutiles / données',
  'read documentation' => 'lire la documentation',
  'event search' => 'Recherche d`événements',
  'group search' => 'Recherche de groupe',
  'page search by location' => 'Page de recherche par emplacement',
  'page search' => 'Page de recherche',
  'user search' => 'Recherche d`utilisateur',
  'lead list' => 'liste de plomb',
  'native API' => 'originaire de API'
);