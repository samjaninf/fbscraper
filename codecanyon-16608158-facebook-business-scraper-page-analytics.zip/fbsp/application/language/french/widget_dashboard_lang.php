
<?php 

$lang = 
array (
  'Total Search Vs Result Found (Today\'s Report)' => 'Recherche total Vs Résultat Trouvé (rapport d\'aujourd\'hui)',
  'Total Collected Emails (Today\'s Report)' => 'Total des e-mails collectées (Rapport des Aujourd\'hui)',
  'widget' => 'un widget',
  'domain name' => 'nom de domaine',
  'frame border' => 'bordure de cadre',
  'frame width' => 'largeur du cadre',
  'frame height' => 'hauteur du cadre',
  'frame background HEX' => 'fond frame HEX',
  'text color HEX' => 'la couleur du texte HEX',
  'input border color HEX' => 'entrée couleur de la bordure HEX',
  'icon color HEX' => 'icone couleur HEX',
  'button style' => 'style de bouton',
  'get widget embed code' => 'obtenir le code embed widget de',
  'click to copy' => 'cliquez pour copier',
  'widget preview' => 'aperçu widget de',
  'how the widget will look in to your website?' => 'comment le widget va chercher à votre site Web?',
  'have a look' => 'regarde', 
  "copy the html code, put it in the websites's html and let website users to use awesome facebook page search" =>"copier le code html, le mettre dans le html des sites Web et permettent aux utilisateurs de site Web pour utiliser impressionnant recherche page facebook",
  "emails from page search"=>"recherche Page emails - backend",
  "emails from guest search"=>"recherche Page emails - frontend",
  "emails from guest user"=>"Invité Utilisateurs emails",
  "page list searched by guests"=>"liste des pages recherchées par les clients",
  "total search" => "recherche totale",
  "total result found" => "résultat total trouvé"
);