<?php

$lang = array (
  'advertisement settings' => 'paramÃ¨tres PublicitÃ©',
  'i want to advertise' => 'Je veux faire de la publicitÃ©',
  'i do not want advertise' => 'Je ne veux pas de publicitÃ©',
  'google API settings' => 'paramÃ¨tres de l\'API Google',
  'google API key' => 'google clÃ© API',
  'please enter google API key and make sure Google Map JavaScript API is enabled.' => 'S\'il vous plaÃ®t entrer google clÃ© API et assurez-vous que l\'API Google Map JavaScript est activÃ©.',
  'how to get google API key?' => 'Comment obtenir google clÃ© API?',
  'how to create mailchimp account?' => 'Comment crÃ©er un compte MailChimp?',
  'how to create facebook app and get app id & app secret?' => 'Comment crÃ©er application facebook et obtenir app id & app secret?',
  'cron job' => 'Cron',
);