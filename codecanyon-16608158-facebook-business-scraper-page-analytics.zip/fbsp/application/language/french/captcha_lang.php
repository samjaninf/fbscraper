<?php

$lang = array (
  'how to get recaptcha site key and secret key' => 'Comment obtenir la clé du site recaptcha et clé secrète',
  'recaptcha secret key' => 'clé secrète Recaptcha',
  'recaptcha site key' => 'Recaptcha clé du site',
  'you have not enter captcha' => 'Vous avez pas entrer captcha',
);