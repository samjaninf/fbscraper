<?php

$lang = array (
  'advertisement settings' => 'advertentie-instellingen',
  'i want to advertise' => 'Ik wil adverteren',
  'i do not want advertise' => 'Ik wil geen reclame maken',
  'google API settings' => 'Google API-instellingen',
  'google API key' => 'Google API-sleutel',
  'please enter google API key and make sure Google Map JavaScript API is enabled.' => 'Vul Google API-sleutel en zorg ervoor dat Google Map JavaScript API is ingeschakeld.',
  'how to get google API key?' => 'Hoe kan ik Google API sleutel te krijgen?',
  'how to create mailchimp account?' => 'Hoe te MailChimp account aan te maken?',
  'how to create facebook app and get app id & app secret?' => 'How to facebook app te maken en krijg app id & app geheim?',
  'cron job' => 'cron job',
);