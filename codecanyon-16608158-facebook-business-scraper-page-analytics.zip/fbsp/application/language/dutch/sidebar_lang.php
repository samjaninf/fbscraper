<?php

$lang = 
array (
  'administration' => 'administratie',
  'user management' => 'user management',
  'send notification' => 'melding verzenden',
  'settings' => 'instellingen',
  'general settings' => 'Algemene instellingen',
  'email settings' => 'e-mailinstellingen',
  'payment' => 'betaling',
  'dashboard' => 'dashboard',
  'payment settings' => 'betalingsinstellingen',
  'payment history' => 'Betaalgeschiedenis',
  'facebook settings' => 'facebook instellingen',
  'lead settings' => 'lead instellingen',
  'proxy settings' => 'Proxy instellingen',
  'delete junk files/data' => 'ongewenste bestanden verwijderen / data',
  'read documentation' => 'Lees documentatie',
  'event search' => 'gebeurtenis zoeken',
  'group search' => 'groep zoeken',
  'page search by location' => 'pagina zoek op locatie',
  'page search' => 'pagina zoeken',
  'user search' => 'gebruiker zoeken',
  'lead list' => 'lead lijst',
  'native API' => 'inheems API' 
);