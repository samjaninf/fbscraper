<?php

$lang = array (
  'how to get recaptcha site key and secret key' => 'Hoe te recaptcha plaats sleutel en de geheime sleutel',
  'recaptcha secret key' => 'Recaptcha geheime sleutel',
  'recaptcha site key' => 'Recaptcha website key',
  'you have not enter captcha' => 'Je hebt niet in captcha',
);
