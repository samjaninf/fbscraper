<?php 
$lang = 
array (
  'Total Search Vs Result Found (Today\'s Report)' => 'Totaal Search Result Vs Gevonden (verslag van vandaag)',
  'Total Collected Emails (Today\'s Report)' => 'Totaal Collected Emails (verslag van vandaag)',
  'widget' => 'widget',
  'domain name' => 'domeinnaam',
  'frame border' => 'frame grens',
  'frame width' => 'Framebreedte',
  'frame height' => 'chassishoogte',
  'frame background HEX' => 'frame achtergrond HEX',
  'text color HEX' => 'tekstkleur HEX',
  'input border color HEX' => 'ingang grens kleur HEX',
  'icon color HEX' => 'kleurpictogram HEX',
  'button style' => 'knopstijl',
  'get widget embed code' => 'Widget embed code',
  'click to copy' => 'klik om te kopiëren',
  'widget preview' => 'widget voorbeeld',
  'how the widget will look in to your website?' => 'hoe de widget eruit zal zien op uw website?',
  'have a look' => 'een kijkje nemen',
   "copy the html code, put it in the websites's html and let website users to use awesome facebook page search" =>"Kopieer de HTML-code, zet het in de websites van html en laat gebruikers van de website te gebruiken ontzagwekkende facebook pagina zoeken",
  "emails from page search"=>"Pagina search e-mails - backend",
  "emails from guest search"=>"Pagina search e-mails - frontend",
  "emails from guest user"=>"Gast gebruikers e-mails",
  "page list searched by guests"=>"pagina lijst doorzocht door gasten",
  "total search" => "totaal zoeken",
  "total result found" => "totaal resultaat gevonden"
);