<?php 
$lang["advertisement settings"]="বিজ্ঞাপন সেটিংস";
$lang["i want to advertise"]="আমি বিজ্ঞাপন দেখাতে চাই";
$lang["i do not want advertise"]="আমি বিজ্ঞাপন দেখাতে চাই না";

$lang['google API settings'] 		= 'গূগল এপিআই সেটিংস';
$lang["google API key"]="গূগল এপিআই কি";
$lang["please enter google API key and make sure Google Map JavaScript API is enabled."]="গূগল এপিআই কি দিন এবং যাচাই করে নিন যে নিন গূগল ম্যাপ জাভাস্ক্রিপ্ট এপিআই চালু করা আছে কি না";
$lang["how to get google API key?"]="কিভাবে গূগল এপিআই কি পাবেন?";
$lang["how to create mailchimp account?"]="কিভাবে মেইলচিম্প একাউন্ট খুলবেন?";
$lang["how to create facebook app and get app id & app secret?"]="কিভাবে ফেসবুক অ্যাপ তৈরি করবেন এবং অ্যাপ আইডি ও অ্যাপ সিক্রেট পাবেন ?";

$lang["cron job"]="ক্রন জব/ সিডিউলার";
?>