<?php

$lang["administration"] 			= "এ্যাডমিন";
$lang["user management"] 			= "ব্যবহারকারী ব্যাবস্থাপনা";
$lang["send notification"] 			= "বার্তা পাঠান";
$lang["settings"] 					= "সেটিংস";
$lang["general settings"] 			= "সাধারণ সেটিংস";
$lang["email settings"] 			= "সিস্টেম ইমেইল সেটিংস - SMTP";
$lang["payment"] 					= "পেমেন্ট";
$lang["dashboard"] 					= "ড্যাসবোর্ড";
$lang["payment settings"] 			= "পেমেন্ট সেটিংস";
$lang["payment history"] 			= "পেমেন্টের তথ্য";
$lang["facebook settings"] 			= "ফেসবুক সেটিংস";
$lang["lead settings"] 				= "লিড সেটিংস";
$lang["proxy settings"] 			= "প্রক্সি সেটিংস";
$lang['delete junk files/data'] 	= "অপ্রয়োজনীয় ফাইল/ডেটা ডিলিট";
$lang['read documentation'] 		= 'নির্দেশিকা পড়ুন';

$lang['event search'] = 'ইভেন্ট সার্চ';
$lang['group search'] = 'গ্রুপ সার্চ';
$lang['page search by location'] = 'পেজ সার্চ - লোকেশনের সাহায্যে';
$lang['page search'] = 'পেজ সার্চ';
$lang['user search'] = 'ইউজার সার্চ';
$lang['lead list'] = 'লিড লিস্ট';
$lang['native API'] = 'স্থানীয় API';
