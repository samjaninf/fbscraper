<?php
$lang['sl']   = "ক্রমিক";	
$lang['last searched at']   = "সর্বশেষ সার্চ করার সময়";	
$lang['last updated at']   = "সর্বশেষ হালনাগাদ করা হয়েছে";	
$lang['total page found']   = "পেজ খূঁজে পাওয়া গেছে";	
$lang['page name']   = "পেজের নাম";	
$lang['fan count']   = "ভক্ত সংখ্যা";	
$lang['downloaded as guest : how many times?']   = "অতিথি হিসাবে মোট কতবার ডাউনলোড করেছেন?";	
$lang['location search']   = "অবস্থান অনুসন্ধান";	
$lang['phone'] = "ফোন";
$lang['founded at'] = "প্রতিষ্ঠাকাল";
$lang['website'] = "ওয়েবসাইট";
$lang['category'] = "ধরণ";
$lang['emails'] = "ইমেল";
$lang['is verified?'] = "যাচাই করা হয়?";
$lang['searched at'] = "অনুসন্ধান করছি";
$lang['username'] = "ব্যবহারকারীর নাম";
$lang['location'] = "অবস্থান";
$lang['founded'] = "প্রতিষ্ঠাকাল";
$lang['start info'] = "স্টার্ট তথ্য";
$lang['mission'] = "উদ্দেশ্য";
$lang['likes'] = "পছন্দগুলি";
$lang['liked pages'] = "পছন্দ পেজ";
$lang['people were talking about'] = "মানুষ সম্পর্কে কথা বলা হয়েছে";
$lang['talking about count'] = "গণ্য সম্পর্কে কথা বলা";
$lang['limit'] = "সীমা";
$lang['distance'] = "দূরত্ব";


$lang['total location search']   = "মোট অবস্থান অনুসন্ধান";	
$lang['total group search']   = "মোট গ্রুপ অনুসন্ধান";	
$lang['total user search']   = "মোট ব্যবহারকারী অনুসন্ধান";	
$lang['total event search']   = "মোট ইভেন্ট অনুসন্ধান";	
$lang['group name']   = "দলের নাম";	
$lang['requested member number']   = "অনুরোধ সদস্য সংখ্যা";	
$lang['privacy']   = "গোপনীয়তা";	
$lang['link']   = "লিংক";	
$lang['total page search']   = "মোট পাতা অনুসন্ধান";	
$lang['event name']   = "অনুষ্ঠানের নাম";	
$lang['attending']   = "আসবেন";	
$lang['interested']   = "আগ্রহী";	
$lang['may be attend']   = "উপস্থিত হতে পারে";
$lang['no reply']   = "উত্তর নেই";
$lang['declined']   = "প্রত্যাখ্যাত";
$lang['searched at']   = "অনুসন্ধান সময়";
$lang['description']   = "বিবরণ";
$lang['group id']   = "গ্রুপ আইডি";
$lang['event id']   = "ইভেন্ট আইডি";
$lang['user id']   = "ইউজার আইডি";
$lang['page id']   = "পেজ আইডি";
$lang['member request count']   = "মেম্বের রিকুএস্ট সংখ্যা";
$lang['owner']   = "মালিক";
$lang['updated at']   = "হালনাগাদ করা হয়েছে";	
$lang['install type']   = "ইন্টলের ধরণ";	
$lang['last name']   = "নামের শেষ অংশ";	
$lang['first name']   = "নামের প্রথম অংশ";	
$lang['middle name']   = "নামেরমধ্য অংশ";	
$lang['about']   = "সম্পর্কে";	
$lang['awards']   = "পুরষ্কার";	
$lang['products']   = "পন্য";	
$lang["you haven't configured your facebook settings yet, please configure first."] = "আপনি এখনও আপনার ফেসবুক এপিআই কনফিগার করেন নি ।";	







