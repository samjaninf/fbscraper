<?php

$lang = array (
  'how to get recaptcha site key and secret key' => 'কিভাবে recaptcha- এর সাইটের কী এবং গোপন চাবি পেতে',
  'recaptcha secret key' => 'Recaptcha গোপন চাবি',
  'recaptcha site key' => 'Recaptcha সাইটের কী',
  'you have not enter captcha' => 'আপনি ক্যাপচা প্রবেশ করেন নি',
);